﻿using UnityEngine;
using System.Collections;

public class RotationFloorScript : MonoBehaviour {

    public GameObject Rotation_Floor;

    public float Speed;

	void Start () {


	
	}
	
	// Update is called once per frame
	void Update () {

        transform.Rotate(new Vector3(0, Speed, 0) * Time.deltaTime);

    }
}
