﻿using UnityEngine;
using System.Collections;

public class particle_PickUp : MonoBehaviour {

    public GameObject particle_Pick_Up;

    //private Vector3 particle_Pick_Up_Rotation;

    // Use this for initialization
    void Start () {

        //particle_Pick_Up_Rotation = new Vector3(-90,0,0);

    }
	
	// Update is called once per frame
	void Update () {
	}
}
