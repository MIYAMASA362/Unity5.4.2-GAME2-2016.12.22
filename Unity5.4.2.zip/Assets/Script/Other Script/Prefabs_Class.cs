﻿using UnityEngine;
using System.Collections;

public class Prefabs_Class : MonoBehaviour {

    public GameObject PrefabX;

    void Start()
    {
        GameObject original = GameObject.Find("Cube");
        GameObject copied = Object.Instantiate(original) as GameObject;
        copied.transform.Translate(2, 0, 0);

    }


    // Update is called once per frame
    void Update () {
	
	}
}
