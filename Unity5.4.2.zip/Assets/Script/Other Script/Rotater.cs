﻿using UnityEngine;
using System.Collections;

public class Rotater : MonoBehaviour {
	
	// Update is called once per frame
	void Update ()
    {
        transform.Rotate(new Vector3(0, 30, 0) * Time.deltaTime);
    }
}
