﻿using UnityEngine;
using System.Collections;

public class Start_Script : MonoBehaviour
{
    public float y = 0.0f;

    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (this.transform.position.y > -5) {
            //y = +0.1f;

            //this.transform.Translate(0, y, 0);
        }

        if(y > 1)
        {
            //Destroy(this);

        }
    }
}