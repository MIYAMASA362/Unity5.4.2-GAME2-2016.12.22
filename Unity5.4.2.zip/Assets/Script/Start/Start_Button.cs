﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Start_Button : MonoBehaviour {

    public GameObject Game_Core;

    //public Scene Next_Scene;

    // Use this for initialization
    void Start () {

	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetButtonDown("Option"))
        {
            SceneManager.LoadScene("Tutorial");

            //SceneManager.MoveGameObjectToScene(Game_Core,Tutorial);
        }

    }
}
