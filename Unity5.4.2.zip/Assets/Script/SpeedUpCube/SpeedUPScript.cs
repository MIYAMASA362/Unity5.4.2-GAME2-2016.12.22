﻿using UnityEngine;
using System.Collections;

public class SpeedUPScript : MonoBehaviour {

	private int SpeedUp;

    private int MAX;


	void Start () {
        SpeedUp = 100;

        MAX = 10;
	}
	
	// Update is called once per frame
	void Update () {

        Debug.Log("SpeedUp"+SpeedUp);

        if (MAX > 0 && MAX <= 10)
        {
            for (int i = 0; i < 10; i++)
            {
                Debug.Log("i" + i);

                MAX = MAX - i;

                SpeedUp = SpeedUp -i;
            }
        }
        
	}
}
