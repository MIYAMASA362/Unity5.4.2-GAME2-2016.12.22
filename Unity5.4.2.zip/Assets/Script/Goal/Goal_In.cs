﻿using UnityEngine;
using System.Collections;

public class Goal_In : MonoBehaviour {

    //public static bool Goal_In;

	// Use this for initialization
	void Start () {
        //Goal_In = false;
	}

    // Update is called once per frame
    void Update() {
    /*
        if (Goal_In == true)
        {
            LoadLevel();
        }
	*/
	}
}
