﻿using UnityEngine;
using System.Collections;

public class Goal_Light : MonoBehaviour {

    public GameObject Goal;

    public Light myLight;

    public static bool Light_Start;

    private Vector3 Dictance;

    // Use this for initialization
    void Start () {

        Dictance = new Vector3(0, 7, 0);

        myLight.intensity = 0;
	
	}
	
	// Update is called once per frame
	void Update () {

        transform.position = Goal.transform.position + Dictance;

        if (Light_Start == true)
        {
            myLight.intensity += 0.1f;
        }
	}
}
