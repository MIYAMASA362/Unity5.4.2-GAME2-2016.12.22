﻿using UnityEngine;
using System.Collections;

public class Goal_Script : MonoBehaviour {

    public static int Get_PickUp;

    public GameObject particle_Goal;

    private bool isCalled = false;

    private Vector3 particle_Goal_Rotation;

    //SendMassesi相手の関数を呼ぶ

    // Use this for initialization
    void Start () {

        Get_PickUp = 0;

        particle_Goal_Rotation = new Vector3(-90,0,0);
       
	}
	
	// Update is called once per frame
	void Update () {
	    transform.Rotate(new Vector3(0,45,0)*Time.deltaTime);

        //ゴール出来る条件になったら
        if (PlayerController.Pick_Up_Number_INFO <= Get_PickUp)
        {
            PlayerController.Goal_Set = true;
            Goal_Light.Light_Start = true;

            if (Time.time > 1.5f) {
                if (isCalled == false) {
                    isCalled = true;

                    //エフェクトの生成
                    Instantiate(
                    particle_Goal,
                    this.transform.position,
                    Quaternion.Euler(particle_Goal_Rotation));
                }
            }
        }
    }
}
