﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Next : MonoBehaviour {

    public string Next_Stage;

    public static bool Next_True;

	// Use this for initialization
	void Start () {
        Next_True = false;
	}
	
	// Update is called once per frame
	void Update () {

        if (Next_True == true)
        {
            SceneManager.LoadScene("Stage1");
        }
    }
}
