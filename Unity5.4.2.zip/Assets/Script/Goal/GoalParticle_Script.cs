﻿using UnityEngine;
using System.Collections;

public class GoalParticle_Script : MonoBehaviour {

    public static bool particle_Destroy;

    public GameObject particle;


	// Use this for initialization
	void Start () {
        particle_Destroy = false;
	}
	
	// Update is called once per frame
	void Update () {

        //消去
        if (particle_Destroy == true) {
            Destroy(particle);
        }
	}
}
