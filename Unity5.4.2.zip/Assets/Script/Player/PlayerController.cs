﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {


    public GameObject Start_Object;

    //初期加速度
    public float Intial_SPEED;

    public Text countText;
    public Text winText;
    public int ObjectNumber;
    public int Pick_Up_Number;
    public bool ExtrStage;

    public string Next;

    private float SPEED = 15.0f;

    public static bool Goal_Set;
    public static int Pick_Up_Number_INFO;
    

    private Rigidbody rb;
    private int count;

    private float Speed_Up;
    private float Speed_Down;
    private float Speed ;

    //移動三次方向
    private float MOVE_X;
    private float MOVE_Z;
    //private float MOVE_Y;
    private float First_Y;

    public object RigidbodyConstrains { get; private set; }

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        SetCountText();
        winText.text = "";

        Goal_Set = false;

        //初期位置の設定
        this.transform.position = new Vector3(
            Start_Object.transform.position.x,
            1,
            Start_Object.transform.position.z
            );
    }


    void Update()
    {
        Goal_Script.Get_PickUp = count;
        Pick_Up_Number_INFO = Pick_Up_Number;

        //ステージ下に落ちた時の処理
        if (this.transform.position.y < -10) {

            this.transform.position = new Vector3(
            Start_Object.transform.position.x,
            1,
            Start_Object.transform.position.z
            );

            //Speed = 0;

            rb.constraints = RigidbodyConstraints.FreezeRotation;
        }

        //加速する設定
        if (Input.GetButton("R2")||Input.GetButtonDown("R2"))
        {
            Speed_Up = 20;
        }
        else
        {
            Speed_Up = 0;
        }

        //減速する設定
        if (Input.GetButton("L2") || Input.GetButtonDown("L2"))
        {
            Speed_Down = 20;
        }
        else
        {
            Speed_Down = 0;
        }

        //Playerの移動ベクトル
        Vector3 movement = new Vector3(
            MOVE_X,
            0,
            MOVE_Z
            );

        //移動ベクトル
        Speed = SPEED + Speed_Up - Speed_Down;

        if (Speed <= 0)
        {
            Speed = 0.0f;

            rb.constraints=RigidbodyConstraints.FreezeRotation;
        }
        else
        {
            rb.constraints = RigidbodyConstraints.None;
        }


        rb.AddForce(
            movement * Speed
        );
    }

    //入力操作についての処理
    void FixedUpdate()
    {
        //動作の設定
        float moveHorizontal = Input.GetAxis("X_MOVE");
        float moveVertical = Input.GetAxis("Y_MOVE");

        MOVE_X = moveHorizontal;
        MOVE_Z = moveVertical;

    }

    void OnTriggerEnter(Collider other)
    { 
        //PICK_UPに触れた時の処理
        if(other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            SetCountText();
        }

        //ゴールに当たった時の処理
        if (other.gameObject.CompareTag("GOAL") && Goal_Set == true)
        {
            other.gameObject.SetActive(false);
            GoalParticle_Script.particle_Destroy = true;
            //Next.Next_True = true;

            SceneManager.LoadScene(Next);


            //Goal_in.Goal_In = true;
        }
    }

    //一定数PICK_UPを取得した時の処理
    void SetCountText ()
    {
        countText.text = "Count:" + count.ToString();
        if (count >= Pick_Up_Number)
        {
            winText.text = "! GO TO THE GOAL !";
        }
    }
    
}
