﻿using UnityEngine;
using System.Collections;

public class PlayerJump : MonoBehaviour {

    private Rigidbody rb;

    //Jumpに関する値
    private float Jump_Y;
    private float Jump_Sub;
    private bool Jump_bool;
    private bool Jump_Down;

    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();
        Jump_bool = false;
    }
	
	// Update is called once per frame
	void Update () {

        if (this.transform.position.y < -10)
        {
            Jump_Y = 0.0f;
        }

        //Jump処理

        //Debug.Log("Jump_Bool" + Jump_bool + "JUMP_Y" + Jump_Y);

        rb.AddForce(new Vector3(0, Jump_Y, 0) * 15.0f);


        //×ボタンを押した時の処理
        if (Input.GetButtonDown("Cross") && Jump_bool == false)
        {
            Jump_Y = 0.0f;

            Jump_bool = true;

        }

        if (Jump_bool == true && Jump_Down == false)
        {
            Jump_Y = 3.0f;
        }

        if (Jump_Y >= 3.0f)
        {
            Jump_Down = true;
        }

        if (Jump_Down == true)
        {
            Jump_Y -= 0.2f;
        }

    }

    //Stageに触れた瞬間
    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Stage"))
        {
            Jump_bool = false;

            Jump_Y = 0.0f;

            Jump_Down = false;
        }
    }

    //Stageに触れてる間
    void OnCollisionStay(Collision other)
    {
        if (other.gameObject.CompareTag("Stage"))
        {
            
        }
    }

    //Stageから離れた瞬間
    void OnCollisionExit(Collision other)
    {
        if (other.gameObject.CompareTag("Stage"))
        {

        }
    }
}
