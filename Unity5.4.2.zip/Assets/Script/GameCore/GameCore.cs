﻿using UnityEngine;
using System.Collections;
using System;

public class GameCore : MonoBehaviour {

    private float Game_Time;

    public static bool Time_Bool;
    public static int Deth_Count;


    void Start () {

        Deth_Count = 0;

        Game_Time = 0.0f;

        Time_Bool = false;
	}

    void Update () {

        //print(Time.realtimeSinceStartup);

        //Debug.Log(Game_Time);

        if (Time_Bool == true)
        {
            Game_Time = Time.realtimeSinceStartup;
        }
    }
}
